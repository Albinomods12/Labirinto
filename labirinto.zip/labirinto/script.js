const WIDTH = 20;
const HEIGHT = 10;
let playerPos = [0, 0];
let movementLog = [];
let stats = { wins: 0, losses: 0, lives: 3 };
let timer;
let intervalId;

function createMaze(level) {
    let maze = Array.from({ length: HEIGHT }, () => Array(WIDTH).fill(' '));
    maze[HEIGHT - 1][WIDTH - 1] = 'F';  // Linha de chegada

    const numTraps = 5 + level * 3;
    let traps = 0;

    while (traps < numTraps) {
        const x = Math.floor(Math.random() * HEIGHT);
        const y = Math.floor(Math.random() * WIDTH);
        if ((x !== 0 || y !== 0) && (x !== HEIGHT - 1 || y !== WIDTH - 1) && maze[x][y] !== 'X') {
            maze[x][y] = 'X';  // Piso falso
            traps++;
        }
    }

    return maze;
}

function drawMaze(maze) {
    const mazeDiv = document.getElementById('maze');
    mazeDiv.innerHTML = '';

    for (let i = 0; i < HEIGHT; i++) {
        for (let j = 0; j < WIDTH; j++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            if (playerPos[0] === i && playerPos[1] === j) {
                cell.classList.add('P');  // Jogador
            } else if (maze[i][j] === 'X') {
                cell.classList.add('X');  // Piso falso
            } else if (maze[i][j] === 'F') {
                cell.classList.add('F');  // Linha de chegada
            }
            mazeDiv.appendChild(cell);
        }
    }

    document.getElementById('movement-log').innerText = movementLog.join(' -> ');
    document.getElementById('lives').innerText = stats.lives;
}

function updateTimer() {
    timer -= 1;
    document.getElementById('timer').innerText = timer;
    if (timer <= 0) {
        clearInterval(intervalId);
        stats.losses += 1;
        alert("O tempo acabou! Game Over.");
        resetGame();
    }
}

function movePlayer(direction) {
    const moves = {
        'w': [-1, 0],
        's': [1, 0],
        'a': [0, -1],
        'd': [0, 1]
    };

    const [dx, dy] = moves[direction];
    const newPos = [playerPos[0] + dx, playerPos[1] + dy];

    if (newPos[0] >= 0 && newPos[0] < HEIGHT && newPos[1] >= 0 && newPos[1] < WIDTH) {
        playerPos = newPos;
        movementLog.push(direction);
        checkCell();
        drawMaze(maze);
    }
}

function checkCell() {
    const cell = maze[playerPos[0]][playerPos[1]];
    if (cell === 'X') {
        stats.lives -= 1;
        alert("Você caiu em um piso falso! Você perdeu uma vida.");
        if (stats.lives <= 0) {
            stats.losses += 1;
            alert("Você perdeu todas as vidas! Game Over.");
            resetGame();
        } else {
            playerPos = [0, 0];
        }
    } else if (cell === 'F') {
        stats.wins += 1;
        alert("Você chegou à linha de chegada! Parabéns!");
        resetGame();
    }
}

function resetGame() {
    playerPos = [0, 0];
    movementLog = [];
    stats.lives = 3;
    stats.losses = 0;
    timer = 60;
    clearInterval(intervalId);
    startGame();
}

function startGame() {
    const level = 0;  // Níveis podem ser incrementados conforme desejado
    maze = createMaze(level);
    drawMaze(maze);
    timer = 60;
    intervalId = setInterval(updateTimer, 1000);
}

document.addEventListener('keydown', (event) => {
    if (event.key === 'q') {
        alert("Você saiu do jogo.");
        return;
    } else if (event.key === 'p') {
        clearInterval(intervalId);
        alert("Jogo pausado. Pressione qualquer tecla para continuar...");
        startGame();
        return;
    } else if (event.key in {'w': 1, 's': 1, 'a': 1, 'd': 1}) {
        movePlayer(event.key);
    }
});

startGame(); 